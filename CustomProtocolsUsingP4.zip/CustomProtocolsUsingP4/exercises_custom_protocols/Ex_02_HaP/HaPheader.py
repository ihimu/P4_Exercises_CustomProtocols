from scapy.all import *
import sys, os

TYPE_HaP = 0x1234


class HaP(Packet):
    name = "HaP_Header"
    fields_desc = [BitField("ttl", 0, 8),BitField("srcHaP", 0, 32),BitField("dstHaP", 0, 32)]
    def mysummary(self):
        return self.sprintf(" ttl=%ttl% \n srcHaP=%srcHaP% \n dstHaP=%dstHaP% \n")


bind_layers(Ether, HaP, type=TYPE_HaP)
