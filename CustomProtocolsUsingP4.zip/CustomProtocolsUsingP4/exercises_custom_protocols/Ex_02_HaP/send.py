#!/usr/bin/env python3
import argparse
import sys
import socket
import random
import struct


#import netaddr
from scapy.all import sendp, send, get_if_list, get_if_hwaddr
from scapy.all import Packet
from scapy.all import Ether

from HaPheader import HaP

def get_if():
    ifs=get_if_list()
    iface=None # "h1-eth0"
    for i in get_if_list():
        if "eth0" in i:
            iface=i
            break;
    if not iface:
        print("Cannot find eth0 interface")
        exit(1)
    return iface

def main():

    if len(sys.argv)<3:
        print('pass 2 arguments: <HaP destination address> <HaP source address> <MAC address of Port where host is connected> "<message>"')
        exit(1)

    dstMACaddr = sys.argv[3]
    #dstHaPaddr = int(netaddr.IPAddress(sys.argv[1]))
    #srcHaPaddr = int(netaddr.IPAddress(sys.argv[2]))
    dstHaPaddr = int(sys.argv[1])
    srcHaPaddr = int(sys.argv[2])
    message = sys.argv[4]

    iface = get_if()

    print(("sending on interface %s to MAC address %s" % (iface, str(dstMACaddr))))
    pkt =  Ether(src=get_if_hwaddr(iface), dst=dstMACaddr, type = 0x1234)
    #pkt = pkt / HaP (ttl = 10, srcHaP = srcHaPaddr, dstHaP = dstHaPaddr) / message
    pkt = pkt / HaP (ttl = 10, srcHaP = srcHaPaddr, dstHaP = dstHaPaddr) / message
    pkt.show2()
    sendp(pkt, iface=iface, verbose=False)

if __name__ == '__main__':
    main()
